package com.gtbackend.gtbackend.model;

public enum Role{
    USER,
    ADMIN
}